using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject objectPrefab;
    public float spawnInterval = 1.5f;

    void Start()
    {
        InvokeRepeating("SpawnObject", 1f, spawnInterval);
    }

    void SpawnObject()
    {
        float randomX = Random.Range(-8f, 8f);
        Vector2 spawnPos = new Vector2(randomX, 6f);
        Instantiate(objectPrefab, spawnPos, Quaternion.identity);
    }
}